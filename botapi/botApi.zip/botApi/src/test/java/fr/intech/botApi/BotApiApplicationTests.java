package fr.intech.botApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
